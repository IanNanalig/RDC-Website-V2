# Project 24 scoring reference

| Item | Reference |
| --- | --- |
| Project title | Manila Maternal Nutrition and Early-Care Outreach Stations |
| Expected classification | Low |
| Reference total | 54.00 / 100 |
| High-priority threshold | 70.00 / 100 |

| Criterion | Weight | Raw score (0–10) | Weighted contribution | Reference rationale |
| --- | ---: | ---: | ---: | --- |
| Readiness | 20 | 5 | 10.00 | The proposal identifies a limited basis for readiness, but coverage, evidence, or scale is constrained. |
| Level of GAD Responsiveness | 15 | 6 | 9.00 | The proposal supports level of gad responsiveness, with remaining detail or implementation evidence still needed. |
| Spatial Coverage | 15 | 6 | 9.00 | The proposal supports spatial coverage, with remaining detail or implementation evidence still needed. |
| Develop and protect capabilities of individuals and families | 10 | 6 | 6.00 | The proposal supports develop and protect capabilities of individuals and families, with remaining detail or implementation evidence still needed. |
| Transform production sector to generate more quality jobs and competitive products | 5 | 3 | 1.50 | The proposal currently provides limited support for transform production sector to generate more quality jobs and competitive products and needs stronger evidence before a higher score is justified. |
| Promote human and social development | 20 | 6 | 12.00 | The proposal supports promote human and social development, with remaining detail or implementation evidence still needed. |
| Reduce vulnerabilities and protect purchasing power | 10 | 5 | 5.00 | The proposal identifies a limited basis for reduce vulnerabilities and protect purchasing power, but coverage, evidence, or scale is constrained. |
| Increase income-earning ability | 5 | 3 | 1.50 | The proposal currently provides limited support for increase income-earning ability and needs stronger evidence before a higher score is justified. |

The total is the sum of `weight × raw score ÷ 10`. This reference is for tester comparison only; enter project data and Validator Facts through the portal, run the AI Assistant Scorer, and make the actual Validator decision in the application.
