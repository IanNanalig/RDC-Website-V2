# Project 08 scoring reference

| Item | Reference |
| --- | --- |
| Project title | Makati Active Transport Wayfinding and Protected Crossing System |
| Expected classification | Low |
| Reference total | 39.00 / 100 |
| High-priority threshold | 70.00 / 100 |

| Criterion | Weight | Raw score (0–10) | Weighted contribution | Reference rationale |
| --- | ---: | ---: | ---: | --- |
| Readiness | 20 | 3 | 6.00 | The proposal currently provides limited support for readiness and needs stronger evidence before a higher score is justified. |
| Level of GAD Responsiveness | 15 | 5 | 7.50 | The proposal identifies a limited basis for level of gad responsiveness, but coverage, evidence, or scale is constrained. |
| Spatial Coverage | 15 | 5 | 7.50 | The proposal identifies a limited basis for spatial coverage, but coverage, evidence, or scale is constrained. |
| Develop and protect capabilities of individuals and families | 10 | 4 | 4.00 | The proposal identifies a limited basis for develop and protect capabilities of individuals and families, but coverage, evidence, or scale is constrained. |
| Transform production sector to generate more quality jobs and competitive products | 5 | 4 | 2.00 | The proposal identifies a limited basis for transform production sector to generate more quality jobs and competitive products, but coverage, evidence, or scale is constrained. |
| Achieve seamless and inclusive connectivity | 20 | 5 | 10.00 | The proposal identifies a limited basis for achieve seamless and inclusive connectivity, but coverage, evidence, or scale is constrained. |
| Provide sustainable energy and water infrastructure | 10 | 1 | 1.00 | The proposal currently provides limited support for provide sustainable energy and water infrastructure and needs stronger evidence before a higher score is justified. |
| Support social development through infrastructure | 5 | 2 | 1.00 | The proposal currently provides limited support for support social development through infrastructure and needs stronger evidence before a higher score is justified. |

The total is the sum of `weight × raw score ÷ 10`. This reference is for tester comparison only; enter project data and Validator Facts through the portal, run the AI Assistant Scorer, and make the actual Validator decision in the application.
